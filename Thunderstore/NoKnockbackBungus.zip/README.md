# NoKnoxkbackBungus

Removes knockback while you are under the effects of Bungus. 

OP? Yeah, probably a bit in the beginning. But standing still is asking for death in higher difficulties anyways.

Art creds to drunkseal_ on reddit (I just googled bungus for a photo and liked this one)